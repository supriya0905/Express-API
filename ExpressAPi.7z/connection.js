const express = require('express');

exports.getApi = function (req, res) {
  console.log("hit")
  // var client = "bdfelastic.rxcorp.com";
  // client.cat.health({
  //   format: string,
  //   h: string | string,
  //   help: boolean,
  //   s: string | string,
  //   time: 'd (Days)' | 'h (Hours)' | 'm (Minutes)' | 's (Seconds)' | 'ms (Milliseconds)' | 'micros (Microseconds)' | 'nanos (Nanoseconds)',
  //   ts: boolean,
  //   v: boolean
  // })
}

